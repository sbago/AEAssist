﻿using System;

namespace AEAssist
{
    public static class ConstValue
    {
        public static int AnimationLockMs = 700;
        public static int AuraTick = 3000;
    }
}