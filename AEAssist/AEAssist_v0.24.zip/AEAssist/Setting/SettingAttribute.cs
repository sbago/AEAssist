﻿using System;

namespace AEAssist
{
    public class SettingAttribute : Attribute
    {
        
    }
}