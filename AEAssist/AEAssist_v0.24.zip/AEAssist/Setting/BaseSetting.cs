﻿namespace AEAssist
{
    public interface IBaseSetting
    {

    }
}