﻿namespace AEAssist
{
    public class VersionSetting
    {
        public VersionSetting()
        {
            this.SettingVersion = ConstValue.SettingVersion;
        }

        public int SettingVersion;
    }
}